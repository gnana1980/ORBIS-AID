# 🏗️ NGO SaaS Platform - STEP 1: FOUNDATION & ARCHITECTURE

## 📋 Overview

This is **STEP 1** of building a production-ready, multi-tenant NGO Project & Finance Management SaaS Platform. This step focuses on:

- Complete project structure (Backend & Frontend)
- Database schema design with Prisma
- Multi-tenancy architecture
- Docker containerization
- Initial seed data

---

## 🏛️ Architecture Highlights

### Multi-Tenancy Model
- **Single Database** with tenant isolation
- **Row-Level Security (RLS)** in PostgreSQL
- **Tenant Context** resolved from JWT tokens
- **Super Admin** can bypass tenant restrictions

### Tech Stack
- **Backend**: Node.js, NestJS, TypeScript, Prisma ORM
- **Frontend**: React, TypeScript, Tailwind CSS, Vite
- **Database**: PostgreSQL 15
- **Cache**: Redis (Optional)
- **Payments**: Razorpay (India)
- **Containerization**: Docker & Docker Compose

---

## 📁 Project Structure

```
ngo-saas-platform/
├── ngo-saas-backend/          # NestJS Backend API
│   ├── src/
│   │   ├── modules/           # Feature modules
│   │   ├── common/            # Guards, decorators, interceptors
│   │   ├── config/            # Configuration
│   │   └── database/          # Seed scripts
│   ├── prisma/
│   │   ├── schema.prisma      # Database schema
│   │   └── migrations/        # Database migrations
│   ├── Dockerfile
│   └── package.json
│
├── ngo-saas-frontend/         # React Frontend
│   ├── src/
│   │   ├── pages/             # Page components
│   │   ├── components/        # Reusable components
│   │   ├── services/          # API services
│   │   ├── hooks/             # Custom hooks
│   │   └── context/           # React context
│   ├── Dockerfile
│   └── package.json
│
└── docker-compose.yml         # Complete stack orchestration
```

---

## 🚀 Getting Started

### Prerequisites

- **Node.js** 18+ and **npm**
- **Docker** and **Docker Compose** (recommended)
- **PostgreSQL** 15+ (if not using Docker)
- **Razorpay Account** for payment processing

---

## 📦 Installation

### Option 1: Using Docker (Recommended)

1. **Clone the repositories**:
```bash
mkdir ngo-saas-platform && cd ngo-saas-platform
```

2. **Create Backend**:
```bash
mkdir ngo-saas-backend
cd ngo-saas-backend
npm init -y
# Copy all backend files here
```

3. **Create Frontend**:
```bash
cd ..
mkdir ngo-saas-frontend
cd ngo-saas-frontend
npm create vite@latest . -- --template react-ts
# Copy all frontend files here
```

4. **Configure Environment**:
```bash
# In backend directory
cp .env.example .env
# Edit .env with your configurations
```

5. **Start All Services**:
```bash
cd ..  # Back to root
docker-compose up -d
```

6. **Run Migrations & Seed**:
```bash
docker-compose exec backend npx prisma migrate deploy
docker-compose exec backend npm run prisma:seed
```

---

### Option 2: Local Development (Without Docker)

#### Backend Setup

```bash
cd ngo-saas-backend

# Install dependencies
npm install

# Setup environment
cp .env.example .env
# Edit .env with your PostgreSQL connection

# Generate Prisma Client
npm run prisma:generate

# Run migrations
npm run prisma:migrate

# Seed database
npm run prisma:seed

# Start development server
npm run start:dev
```

Backend will run on: **http://localhost:3000**

#### Frontend Setup

```bash
cd ngo-saas-frontend

# Install dependencies
npm install

# Setup environment
cp .env.example .env
# Set VITE_API_URL=http://localhost:3000/api

# Start development server
npm run dev
```

Frontend will run on: **http://localhost:5173**

---

## 🗄️ Database Schema

### Core Tables

#### Platform Level (Super Admin)
- **tenants** - NGO organizations
- **plans** - Subscription plans
- **subscriptions** - Active subscriptions
- **payments** - Payment transactions
- **invoices** - Billing invoices
- **usage_metrics** - Usage tracking

#### Tenant Level (NGO)
- **users** - NGO users
- **roles** & **permissions** - RBAC
- **projects** - NGO projects
- **beneficiaries** - Beneficiary records
- **donors** - Donor profiles
- **donations** - Donation transactions
- **funds** - Fund management
- **accounts** - Chart of accounts
- **journal_entries** - Journal entries
- **ledger_entries** - General ledger
- **expenses** - Expense tracking
- **approvals** - Approval workflows
- **compliance_documents** - Regulatory docs
- **audit_logs** - Complete audit trail

---

## 🔐 Default Credentials

### Super Admin (Platform Admin)
- **URL**: http://localhost:3000/platform
- **Email**: admin@ngosaas.com
- **Password**: SuperAdmin@123

### Demo Tenant (NGO Admin)
- **Subdomain**: demo.ngosaas.com
- **URL**: http://localhost:3000
- **Email**: admin@demo.ngosaas.com
- **Password**: Demo@123

**⚠️ IMPORTANT**: Change these passwords in production!

---

## 📊 Database Migrations

```bash
# Create a new migration
npm run prisma:migrate -- --name add_new_feature

# Apply migrations (Production)
npm run prisma:deploy

# Reset database (Development only!)
npx prisma migrate reset

# Open Prisma Studio (Database GUI)
npm run prisma:studio
```

---

## 🧪 Seeded Data

After running `npm run prisma:seed`, you'll have:

### Subscription Plans
1. **Starter** - ₹0/month (Free tier)
2. **Growth** - ₹2,999/month
3. **Professional** - ₹5,999/month
4. **Enterprise** - ₹14,999/month

### Roles
1. **NGO Admin** - Full access
2. **Project Manager** - Projects & beneficiaries
3. **Finance Manager** - Finance & donors
4. **Field Staff** - Read-only access
5. **Donor** - View reports only

### Permissions
- 24 granular permissions across all modules
- Role-based access control (RBAC)

---

## 🔍 Key Features of Database Schema

### 1. Multi-Tenancy
- Every business table has `tenant_id`
- RLS policies enforce data isolation
- Super Admin can access all tenants

### 2. Soft Deletes
- Important tables have `deletedAt` field
- Data is never physically deleted
- Audit trail preserved

### 3. Financial Immutability
- Posted journal entries cannot be modified
- Complete audit trail for finance
- Double-entry accounting enforced

### 4. Comprehensive Indexing
- Optimized queries with strategic indexes
- Foreign keys indexed by default
- Tenant + status composite indexes

---

## 🎯 Next Steps

Once STEP 1 is complete and verified:

✅ Database schema is designed
✅ Multi-tenancy is configured
✅ Seed data is loaded
✅ Docker setup is working

**Proceed to STEP 2**: Authentication & RBAC Implementation

---

## 🐛 Troubleshooting

### Database Connection Issues
```bash
# Check if PostgreSQL is running
docker-compose ps

# View PostgreSQL logs
docker-compose logs postgres

# Restart PostgreSQL
docker-compose restart postgres
```

### Migration Errors
```bash
# Check migration status
npx prisma migrate status

# Resolve migration conflicts
npx prisma migrate resolve --applied "migration_name"
```

### Port Already in Use
```bash
# Find and kill process using port 3000
lsof -ti:3000 | xargs kill -9

# Or change port in .env
PORT=3001
```

---

## 📚 Additional Resources

- [NestJS Documentation](https://docs.nestjs.com)
- [Prisma Documentation](https://www.prisma.io/docs)
- [PostgreSQL RLS Guide](https://www.postgresql.org/docs/current/ddl-rowsecurity.html)
- [Razorpay API Docs](https://razorpay.com/docs/api)

---

## 🤝 Support

For questions or issues with STEP 1:
1. Check the troubleshooting section
2. Review the architecture diagrams
3. Verify all environment variables
4. Ensure Docker services are running

---

## ✅ STEP 1 Completion Checklist

Before moving to STEP 2, verify:

- [ ] Docker containers are running
- [ ] Database is accessible
- [ ] Migrations have been applied
- [ ] Seed data is loaded
- [ ] Super Admin login works
- [ ] Demo tenant is created
- [ ] All environment variables are set
- [ ] Backend API is responding
- [ ] Frontend is accessible

---

**Ready to proceed?** Reply with **"Proceed to STEP 2"** to continue with Authentication & RBAC implementation!

